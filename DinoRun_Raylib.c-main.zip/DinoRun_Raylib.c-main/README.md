# 2D Dino Run Game built using Raylib

Dino Project for Final Project CS-172

<hr/>
<img src="https://github.com/uwussimo/dino.cpp/blob/main/assets/Project%20Dino%20Run-1.png?raw=true" />
<img src="https://github.com/uwussimo/dino.cpp/blob/main/assets/Project%20Dino%20Run-2.png?raw=true" />
<img src="https://github.com/uwussimo/dino.cpp/blob/main/assets/Project%20Dino%20Run-3.png?raw=true" />
<img src="https://github.com/uwussimo/dino.cpp/blob/main/assets/Project%20Dino%20Run-4.png?raw=true" />
<img src="https://github.com/uwussimo/dino.cpp/blob/main/assets/Project%20Dino%20Run-5.png?raw=true" />
<img src="https://github.com/uwussimo/dino.cpp/blob/main/assets/Project%20Dino%20Run-6.png?raw=true" />
<img src="https://github.com/uwussimo/dino.cpp/blob/main/assets/Project%20Dino%20Run-7.png?raw=true" />
<img src="https://github.com/uwussimo/dino.cpp/blob/main/assets/Project%20Dino%20Run-8.png?raw=true" />
<img src="https://github.com/uwussimo/dino.cpp/blob/main/assets/Project%20Dino%20Run-9.png?raw=true" />
<img src="https://github.com/uwussimo/dino.cpp/blob/main/assets/Project%20Dino%20Run-10.png?raw=true" />
<img src="https://github.com/uwussimo/dino.cpp/blob/main/assets/Project%20Dino%20Run-11.png?raw=true" />
